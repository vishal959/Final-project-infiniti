<?php
/**
|--- Blog Script
|--- What Techniques will be used
|------ MVC Design Pattern
|------ Registry Design Pattern
|------ Factory Design Pattern
|------ Dependency Injection
|------ Front Controller
|------ Namespaces
|------ Interfaces
|------ Singleton
|--- Creating Primary Files And Folders
|--- How the bolg should work
|--- Creating Database Tables
|--- Creating System Files
|--- Creating Backend (Starting MVC)
|--- Creating Frontend
|--- Goodbye
 */