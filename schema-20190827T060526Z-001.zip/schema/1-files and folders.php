<?php
/**
           Files And Folders
- /App
--- /Controllers
--- /Models
--- /Views
--- index.php
- /public
--- /theme
----- /css
----- /js
----- /images
--- /admin
----- /css
----- /js
----- /images
--- /uploads
----- /images
- /vendor
--- /System
- .htaccess
- config.php
- index.php
*/
