<?php
/**
* Application Class + File System
*
* Prerequisites
*
* Basic OOP
* Magic Constants
* Magic Methods
* Autoload Classes
* Access Objects As Arrays [ArrayAccess Interface]
*
* File System
* Autoloading Classes
* Sharing Data | Objects
*