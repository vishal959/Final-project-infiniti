<?php
|--
|- PHP & AJAX => Login System
|-
|- Prerequisites
|- Good Knowledge for jquery
|-
|- Content
|- Creating default administrator
|- Login Form
|- Normal Login Accesss
|- Ajax ?
|- Ajax Login Access
--|