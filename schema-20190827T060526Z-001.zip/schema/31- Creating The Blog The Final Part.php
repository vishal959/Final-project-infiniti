<?php
|--
|- Creating The Blog : The Final Part
|-
|- Content
|- Fixing Small Bug in Access Controller
|- Reviewing Settings Code
|- Adding 2 More Methods(clauses) to Database Class
|- Displaying The BLog Design
|- Creating Blog Routes
|- Creating Home Page
|- Creating Registration Page
|- Creating Login Page
|- Creating Profile Page => Will Be Assigned as task
|- Creating Category Page
|- Creating Pagination Class
|- Creating Search Page  => Will Be Assigned as task
|- Creating Post Page
|- Creating Comments
|- Creating Contact Us Page
|- Creating About Us Page
|- The End.
--|
?>