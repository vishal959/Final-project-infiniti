<?php
|--
|- Finishing Admin Panel
|-
|- Users Groups Page
|- logout Page
|- Users Page
|- Posts Page
|- Ads Page
|- Settings Page
|-
|-
|- Users Groups Permissions
|-
|- Current User :
|- Name :Hasan
|- Email : foo@bar.com
|- users_group_id = 3
|-
|- /admin
|- Users Group id = > 3
|- page => /admin/users/edit/:id
|- page => /admin/users/edit/:id
|- page => /admin/users/add
|- page => /admin/users : relative path
|- page => localhost/blog/admin/users : absolute path
|- page => sitename.com/blog/admin/users : absolute path
|-
|- Midlleware ?
|-
--|

