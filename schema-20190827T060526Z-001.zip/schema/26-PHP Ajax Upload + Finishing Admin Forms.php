<?php
|--
|- PHP Ajax Upload + Finishing Admin Forms
|-
|- Pre-Requisites
|- jQuery
|- Ajax using jQuery
--|