<?php
/**
* Application Class Part II
*
* Prerequisites
*
* Basic OOP
* Magic Constants
* Magic Methods
* Autoload Classes
* Access Objects As Arrays [ArrayAccess Interface]
*
* More Advanced Sharing
* Lazy loading
*