<?php
/**
* Create Index file and generate clean urls
*
* Prerequisites
* PHP Version 5.4+
* Apache mod_rewrite enabled                           
*/