<?php
|--
|- Editing Admin Panel Common sections
|-
|- Content
|- Fixing CKEditor
|- Previewing Settings Page
|- Adding Sidebar Links
|- How To Get The current url using javascript
|- Adjusting Breadcrumbs in every page
|- Creating Profile Page
|- What Next In Admin Panel
|-
|- It Will be three things to do
|- First One is Creating Reports in main dashboard page
|- Reviewing Comments on Posts
|- Replying to contacts
--|
?>
