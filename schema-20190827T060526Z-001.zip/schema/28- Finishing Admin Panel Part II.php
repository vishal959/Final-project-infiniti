<?php
|--
|- Finishing Admin Panel Part II
|-
|- Users Page
|- Posts Page
|- Ads Page
|- Settings Page
|- You will create Settings page as normal page without ajax loading
|- Settings will be set on it as follows :
|- Site Name
|- Site Status : On - Off
|- Site Email
|- That's all
|- Site Close Message : as this will be displayed if site status is Off
--|

