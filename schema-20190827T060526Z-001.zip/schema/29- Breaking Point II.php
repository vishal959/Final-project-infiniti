<?php
|--
|- Breaking Point II
|-
|- Content
|- What you should have accomplished by watching this series to now
|-
|- Building Fully OOP Website
|- MVC Design Pattern
|- Factory Design Pattern
|- Front Controller "index.php"
|- Dependency Injection
|- Singleton
|- Interfaces
|- Namespaces
|- Autoloading Classes
|- Routing System
|- Login System
|- Building Core For your System
|- Handing Forms + Uploaded Files With Validation
|- Handing Forms + Uploaded Files With Validation Using Ajax
|- Creating Crud Systems "Create, Read, Update, Delete Records"
|- Creating Crud Systems Using Ajax
|-
|-
|- Our Progress about 80%
|- Don't Watch the next tutorials if you don't understand any of the previous tutorials
|-
|- What Will Be Done By This weekend
|-
|- Finishing the admin panel with some final touches
|- Home Page + Setting Ads
|- Registration Page + Login Page
|- Categories Page + Pagination Class
|- Post Page + Comments
|- Search Page
|- Contact Page
|- The Final Tutorial => Whaht Next
--|