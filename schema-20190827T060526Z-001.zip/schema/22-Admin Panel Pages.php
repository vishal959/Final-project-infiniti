<?php
|--
|- Admin Panel Pages
|-
|- Content
|- Categories Page  => list + form
|- Posts Page  => list + form
|- Users Page  => list + form
--|