        <div class="clearfix"></div>
    </div>
    <!--/ Content -->
    <!-- Footer -->
    <footer>
        <div class="copyrights">
            &copy;2019 Infiniti
        </div>
        <div class="social">
        <a href="https://www.facebook.com/" class="facebook">
                        <span class="fa fa-facebook"></span>
                    </a>
                    <a href="https://aboutme.google.com/u/0/?referer=gplus" class="google">
                        <span class="fa fa-google-plus"></span>
                    </a>
                    <a href="https://twitter.com/" class="twitter">
                        <span class="fa fa-twitter"></span>
                    </a>
                    <a href="https://www.youtube.com/" class="youtube">
                        <span class="fa fa-youtube"></span>
                    </a>
        </div>
    </footer>
    <!--/ Footer -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-2.2.4.min.js"  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="   crossorigin="anonymous"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo assets('blog/js/bootstrap.min.js'); ?>"></script>
    <!-- WOW JS -->
    <script src="<?php echo assets('blog/js/wow.min.js'); ?>"></script>
    <!-- Custom JS -->
    <script src="<?php echo assets('blog/js/custom.js'); ?>"></script>
  </body>
</html>